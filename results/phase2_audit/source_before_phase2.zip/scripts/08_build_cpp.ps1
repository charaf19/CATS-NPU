# Optional, requires CMake + MSVC Build Tools (or another C++17 compiler).
$ErrorActionPreference = 'Stop'
Set-Location (Resolve-Path (Join-Path $PSScriptRoot '..'))
$cmake = Get-Command cmake.exe -ErrorAction SilentlyContinue
if ($null -eq $cmake) {
    throw 'CMake is not installed or not on PATH. Install CMake and the Visual Studio C++ build workload, then open a new PowerShell session.'
}
Write-Host "Using CMake: $($cmake.Source)"
& $cmake.Source -S native -B native/build
if ($LASTEXITCODE -ne 0) { throw 'CMake configuration failed' }
& $cmake.Source --build native/build --config Release
if ($LASTEXITCODE -ne 0) { throw 'C++ build failed' }
Write-Host 'Optional C++ CPU baseline built. Run 05_benchmark_cpu.ps1 again.'
